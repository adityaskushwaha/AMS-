import { describe, expect, it } from "vitest";
import { allClasses } from "@/lib/data";

describe("Student roll numbers", () => {
  it("assigns exactly 720 unique sequential rolls from 202410101150001 to 202410101150720", () => {
    const rolls = allClasses.flatMap((c) => c.students.map((s) => s.roll));
    expect(rolls).toHaveLength(720);
    expect(new Set(rolls).size).toBe(720);
    expect(rolls[0]).toBe("202410101150001");
    expect(rolls.at(-1)).toBe("202410101150720");
    expect(rolls).toEqual(Array.from({ length: 720 }, (_, i) => String(202410101150001 + i)));
  });
});