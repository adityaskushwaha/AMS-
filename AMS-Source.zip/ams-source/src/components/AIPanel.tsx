import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles, Loader2 } from "lucide-react";
import { askAI } from "@/lib/ai.functions";
import { Button } from "@/components/ui/button";

export function AIPanel({ context, suggestions }: { context: () => string; suggestions: string[] }) {
  const ask = useServerFn(askAI);
  const [q, setQ] = useState("");
  const [answer, setAnswer] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function run(question: string) {
    if (!question.trim() || busy) return;
    setBusy(true); setErr(""); setAnswer(""); setQ(question);
    try {
      const r = await ask({ data: { question, context: context() } });
      if (r.error) setErr(r.error); else setAnswer(r.text);
    } catch { setErr("The AI assistant could not answer right now."); }
    setBusy(false);
  }

  return (
    <section className="section-block">
      <div className="flex items-center gap-2">
        <Sparkles className="h-5 w-5 text-muted-foreground" />
        <h2 className="text-lg font-semibold">AI Insights</h2>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {suggestions.map((s) => (
          <Button key={s} variant="secondary" disabled={busy} onClick={() => run(s)} className="h-auto min-h-9 whitespace-normal text-left">{s}</Button>
        ))}
      </div>
      <form onSubmit={(e) => { e.preventDefault(); run(q); }} className="mt-4 flex gap-2">
        <input aria-label="Attendance question" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ask about attendance…" className="field min-w-0 flex-1" />
        <Button type="submit" disabled={busy}>{busy ? <Loader2 className="h-4 w-4 animate-spin" /> : "Ask"}</Button>
      </form>
      {err && <p className="mt-4 text-sm text-foreground">{err}</p>}
      {answer && <div className="mt-4 whitespace-pre-wrap rounded-md bg-muted p-4 text-[15px] leading-relaxed">{answer}</div>}
    </section>
  );
}
